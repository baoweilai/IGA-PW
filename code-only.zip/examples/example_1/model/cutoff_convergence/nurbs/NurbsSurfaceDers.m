function [W,DW, D2W,F,DF,D2F]=NurbsSurfaceDers(ConPts,knotU,knotV,weights,pu,u,pv,v)
% Evaluate NURBS surface derivatives.
% Evaluate the one-dimensional basis derivatives and active control net.
Uders=bspbasisDers(knotU,pu,u,2);
Nu=Uders(1,:);
DNu=Uders(2,:);
D2Nu=Uders(3,:);

Vders=bspbasisDers(knotV,pv,v,2);
Nv=Vders(1,:)';
DNv=Vders(2,:)';
D2Nv=Vders(3,:)';

i=findspan(knotU,pu,u);
j=findspan(knotV,pv,v);
u_index=i-pu:i;
v_index=j-pv:j;

w_ij=weights(u_index,v_index);

P_u=ConPts(u_index,v_index,1);
P_v=ConPts(u_index,v_index,2);

DIM=2;


F=zeros(DIM,1);


% Compute the rational weight, surface point, and weight derivatives.
W = Nu * w_ij * Nv;
DW=zeros(1,DIM);
DW(1) = DNu*w_ij*Nv;
DW(2) = Nu*w_ij*DNv;

F(1) = Nu * (w_ij.*P_u)*Nv/W;
F(2) = Nu * (w_ij.*P_v)*Nv/W;

D2W = zeros(DIM,DIM);

D2W(1,1)=D2Nu*w_ij*Nv; D2W(1,2) = DNu * w_ij *DNv;
D2W(2,1) = D2W(1,2);   D2W(2,2) = Nu  * w_ij *D2Nv;

W2 = W*W;
W4 = W2*W2;


% Form the surface Jacobian from rational basis derivatives.
R_DNu = (DNu*W-Nu*DW(1))/W2;
R_DNv = (DNv*W-Nv*DW(2))/W2;

DF=zeros(DIM,DIM);

DF(1,1) = R_DNu *(P_u.*w_ij)*Nv;
DF(1,2) = Nu *(P_u.*w_ij)*R_DNv;

DF(2,1) = R_DNu *(P_v.*w_ij)*Nv;
DF(2,2) = Nu *(P_v.*w_ij)*R_DNv;

D2F=zeros(DIM,DIM,DIM);


% Form the surface Hessian and mixed derivatives.
R_D2Nu =  ( (D2Nu*W-Nu*D2W(1,1))*W2-(DNu*W-Nu*DW(1))*2*W*DW(1) )/W4;
R_D2Nv =  ( (D2Nv*W-Nv*D2W(2,2))*W2-(DNv*W-Nv*DW(2))*2*W*DW(2) )/W4;
R_D2Nuv=  ( (DNu*DW(2) - Nu*D2W(1,2) )*W2- (DNu*W - Nu*DW(1))*2*W*DW(2) )/W4;

D2F(1,1,1) = R_D2Nu*(w_ij.*P_u)*Nv;
D2F(1,2,1) = R_DNu *(w_ij.*P_u)*DNv +  R_D2Nuv * (w_ij.*P_u)*Nv;
D2F(2,1,1) = R_D2Nu*(w_ij.*P_v)*Nv;
D2F(2,2,1) = R_DNu *(w_ij.*P_v)*DNv +  R_D2Nuv * (w_ij.*P_v)*Nv;

D2F(1,1,2) = D2F(1,2,1);
D2F(1,2,2) = Nu *(w_ij.*P_u)*R_D2Nv;
D2F(2,1,2) = D2F(2,2,1);
D2F(2,2,2) = Nu *(w_ij.*P_v)*R_D2Nv;


end
